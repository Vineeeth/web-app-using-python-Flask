import flask as flask             
      #This is a Python library that allows for easy creation of web applications
from flask import Response        
      #The code then imports the Response class, which is used to create responses from flask
from flask import Flask,flash      
      #it imports the Flask and flash libraries, which are used to create user interfaces in flask apps.
from flask import request
      #it imports request and render_template from flask so that they can be used in this program as well as any other programs created with this code base
from flask import render_template  
      #from werkzeug import secure_filename
from werkzeug.utils import secure_filename
      #-------For Twitter--------------------
import tweepy
      #--------------------------------------
consumer_key = "m2wMpjaXcu6axdLUV8IyasoKm"
consumer_secret = "NhgM2Au0X9AB1S0jdNoGVUyWkQIk59YW4OhPXuPRmXVAwt8CKN"
access_token = "131564998634c0835329-7vRzxHpaHeOhfGvMVrbpzOlAZlSfA"
access_token_secret = "Db608IYvIeGF064j9WGXqTT2QBiQwbBdWbZR7gr5fHrBE"

      #creating the authentication object
auth = tweepy.OAuthHandler(consumer_key, consumer_secret)

       #setting our access tokens and secrets
auth.set_access_token(access_token, access_token_secret)

#creating  Api object 
api = tweepy.API(auth)
#-----------------------------------------

app = flask.Flask(__name__)

@app.route('/')
def index():
    return flask.render_template("index.html")

@app.route('/login',methods = ['GET','POST'])
def login():
    uname = "admin"
    password = "admin"
    var1 = flask.request.form.get('username')
    var2 = flask.request.form.get('pass')
    if uname == var1 and password == var2:
        return flask.render_template("video.html")
    else:
        return flask.render_template("index.html")


@app.route('/uploader', methods = ['GET', 'POST'])
def upload_file():
   if request.method == 'POST':
      f = request.files['file']
      f.save(secure_filename(f.filename))
      data = f.filename
      api.update_with_media(data,"Upload Success")
      return flask.render_template("success.html")


@app.route('/videofile', methods = ['GET', 'POST'])
def video_fun():
    return flask.render_template("video.html")


if __name__ == '__main__':
    app.run(debug = True)
